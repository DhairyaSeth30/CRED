//original

// import 'package:cred/widget/card.dart';
// import 'package:flutter/material.dart';
//
// import '../widget/bottom_sheet.dart';
// import '../widget/custom_button.dart';
//
// class BaseScreen extends StatefulWidget {
//   final List<dynamic> data; // Declare the data field
//   const BaseScreen({super.key, required this.data});
//
//   @override
//   State<BaseScreen> createState() => _BaseScreenState();
// }
//
// class _BaseScreenState extends State<BaseScreen> {
//   @override
//   Widget build(BuildContext context) {
//     // BottomSheet bottomSheet = BottomSheet(); // Create an instance of the Bottom_Sheet
//
//     return Scaffold(
//       backgroundColor: Color.fromRGBO(46, 44, 44, 100),
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Top section with icons
//           Container(
//             padding: EdgeInsets.only(top: 60, left: 30, right: 30, bottom: 30),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Icon(
//                       Icons.cancel,
//                       size: 30.0,
//                       color: Colors.grey,
//                     ),
//                     Icon(
//                       Icons.help,
//                       size: 30.0,
//                       color: Colors.grey,
//                     ),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 10.0,
//                 ),
//               ],
//             ),
//           ),
//           Expanded(
//             child: Container(
//               width: double.infinity,
//               // height: double.infinity,
//               padding: EdgeInsets.symmetric(horizontal: 20),
//               decoration: BoxDecoration(
//                 color: Color.fromRGBO(46, 44, 44, 50),
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(20.0),
//                   topRight: Radius.circular(20.0),
//                 ),
//               ),
//               child: ListView(
//                 children: [
//                   ListTile(
//                     title: Text(
//                       widget.data[0]['open_state']['body']['title'],
//                       style: TextStyle(
//                         color: Colors.white,
//                       ),
//                     ),
//                     subtitle: Text(
//                       widget.data[0]['open_state']['body']['subtitle'],
//                       style: TextStyle(
//                         color: Colors.white,
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 20,
//                   ),
//                   Center(
//                     child: Container(
//                       height: 400, // Set a specific height for the bottom sheet
//                       child: Card_Sheet(data1: widget.data),
//                     ),
//                   ),
//                   // SizedBox(
//                   //   height: 50,
//                   // ),
//                   // GestureDetector(
//                   //   onTap: () {
//                   //     BottomSheetHelper.showBottomSheet(context, widget.data[1]);
//                   //   },
//                   //   child: Container(
//                   //     width: double.infinity,
//                   //     height: 90,
//                   //     padding: EdgeInsets.symmetric(horizontal: 20),
//                   //     decoration: BoxDecoration(
//                   //       color: Colors.blue,
//                   //       borderRadius: BorderRadius.only(
//                   //         topLeft: Radius.circular(20.0),
//                   //         topRight: Radius.circular(20.0),
//                   //       ),
//                   //     ),
//                   //     child: const Center(
//                   //         child: Text(
//                   //       'Proceed to EMI Selection',
//                   //       style: TextStyle(
//                   //         fontSize: 20,
//                   //         color: Colors.white,
//                   //       ),
//                   //     )),
//                   //   ),
//                   // ),
//
//                 ],
//               ),
//             ),
//           ),
//           CustomButton(
//             text: 'Proceed to EMI Selection',
//             onPressed: () {
//               // Your button press logic
//               BottomSheetHelper.showBottomSheet(context, widget.data);
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }
//

// This below one

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sleek_circular_slider/sleek_circular_slider.dart';

import '../widget/custom_button.dart';

class BaseScreen extends StatefulWidget {
  final List<dynamic> data; // Declare the data field
  const BaseScreen({super.key, required this.data});

  @override
  State<BaseScreen> createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen>
    with TickerProviderStateMixin {
  bool isBottomSheetOpen = false;
  double creditAmount = 150000;
  double maxCredit = 487891;

  AnimationController? _controller;
  Animation<double>? _textAnimation;

  // Animation Controllers and Animations for BottomSheet 2
  AnimationController? _controller2;
  Animation<double>? _textAnimation2;

  int? selectedIndex; // Track the selected container
  late List<Color> containerColors; // Store colors for container
  bool isSelected = false; // To track if the checkbox is selected
  bool isBottomSheet2Open = false;

  late String headText;
  late String emi;



  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );

    _textAnimation = CurvedAnimation(
      parent: _controller!,
      curve: Curves.easeOut,
    );

    _controller!.addListener(() {
      setState(() {});
    });

    // Initialize AnimationController for BottomSheet 2
    _controller2 = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );

    _textAnimation2 = CurvedAnimation(
      parent: _controller2!,
      curve: Curves.easeOut,
    );

    _controller2!.addListener(() {
      setState(() {});
    });

    containerColors = generateContainerColors();
  }

  List<Color> generateContainerColors() {
    final List<Color> colorList = [
      Colors.blue,
      Colors.brown,
      Colors.purple,
      Colors.red,
      Colors.pink,
    ];

    Random random = Random(); // For generating random numbers
    return List.generate(
      widget.data[1]['open_state']['body']['items'].length,
      (index) => colorList[random.nextInt(colorList.length)],
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    _controller2?.dispose();
    super.dispose();
  }

  // <-----------Bottom Sheet 2------------->

  void _showBottomSheet2() {
    setState(() {
      isBottomSheet2Open = true;
    });


    _controller2!.forward(); // Start animation for BottomSheet 2

    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Stack(
            children: [
              AnimatedBuilder(
                animation: _controller2!,
                builder: (context, child) {
                  print('Bottom sheet 2 is $isBottomSheet2Open');
                  return Positioned(
                    top: isBottomSheet2Open ? 80 : 50,
                    left: 20,
                    right: 20,
                    child: Text(
                      isBottomSheet2Open ? "Working" : "Not Working",
                      style: TextStyle(
                        fontSize: 20 + _textAnimation!.value * 20,
                        // Adjust the range as needed
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  );
                },
              ),
              Container(
                height: MediaQuery.of(context).size.height *
                    0.6, // Set height to 30% of the screen
                // height: 400,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20.0),
                    topRight: Radius.circular(20.0),
                  ),
                ),
                child: Column(
                  // crossAxisAlignment: CrossAxisAlignment.stretch,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // SizedBox(height: 5.0),
                    Padding(
                      padding: const EdgeInsets.all(30.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.data[2]['open_state']['body']['title'],
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w500),
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            widget.data[2]['open_state']['body']['subtitle'],
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.w400),
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  // Leading part (Icon)
                                  Icon(Icons.food_bank,
                                      size: 40, color: Colors.blue),
                                  SizedBox(width: 10),
                                  // Middle part (Title and Subtitle)
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.data[2]['open_state']['body']
                                            ['items'][0]['title'],
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(height: 5),
                                      Text(
                                        widget.data[2]['open_state']['body']
                                                ['items'][0]['subtitle']
                                            .toString(),
                                        style: TextStyle(
                                            fontSize: 14, color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              // Trailing part (Circular checkbox for selection)
                              Checkbox(
                                shape: CircleBorder(), // To make it circular
                                value: isSelected,
                                onChanged: (bool? value) {
                                  setState(() {
                                    isSelected = value ?? false;
                                  });
                                },
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          ElevatedButton(
                            onPressed: () {},
                            child: Text('Change account'),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Expanded(
                      child: CustomButton(
                        text: widget.data[2]['cta_text'],
                        onPressed: () {
                          // BottomSheetHelper2.showBottomSheet(context, emiData);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        }).whenComplete(() {
      setState(() {
        isBottomSheet2Open = false;
      });
      _controller2!.reverse(); // Reverse the animation when BottomSheet 2 closes
    });
  }

  // <----------Bottom Sheet 1-------------->

  void _showBottomSheet() {
    String key1 = widget.data[1]['closed_state']['body']['key1'];
    String key2 = widget.data[1]['closed_state']['body']['key2'];
    String title = widget.data[1]['open_state']['body']['title'];
    String subtitle = widget.data[1]['open_state']['body']['subtitle'];

    setState(() {
      isBottomSheetOpen = true;
    });

    _controller!.forward();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      isDismissible: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setBottomSheetState) {
            return Stack(
              children: [
                AnimatedBuilder(
                  animation: _controller!,
                  builder: (context, child) {
                    print('YBottomSheet 2 is $isBottomSheet2Open');
                    return Positioned(
                      top: isBottomSheet2Open ? 170 : 170,
                      left: 20,
                      right: 20,
                      child: isBottomSheet2Open
                          ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Abcdvjkef fklaf djafl',
                                style: const TextStyle(
                                  color: Colors.blueGrey,
                                  fontSize: 25,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                'dfajf dksfjf ll falljfeifakl',
                                style: const TextStyle(
                                  color: Colors.grey,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                          : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              color: Colors.blueGrey,
                              fontSize: 25,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            subtitle,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 15,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),

                DraggableScrollableSheet(
                  initialChildSize: 0.7, // Start at 70% of screen height
                  minChildSize: 0.3, // Minimum height is 30% of screen height
                  maxChildSize: 0.9, // Maximum height is 90% of screen height
                  builder: (context, scrollController) {
                    return Container(
                      decoration: const BoxDecoration(
                        color: Color.fromRGBO(28, 17, 47, 5),
                        borderRadius:
                        BorderRadius.vertical(top: Radius.circular(25.0)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 10.0),
                          // Padding(
                          //   padding: const EdgeInsets.all(30.0),
                          //   child: Column(
                          //     crossAxisAlignment: CrossAxisAlignment.start,
                          //     children: [
                          //       Text(
                          //         title,
                          //         style: const TextStyle(
                          //           color: Colors.blueGrey,
                          //           fontSize: 25,
                          //           fontWeight: FontWeight.w500,
                          //         ),
                          //       ),
                          //       const SizedBox(height: 5),
                          //       Text(
                          //         subtitle,
                          //         style: const TextStyle(
                          //           color: Colors.grey,
                          //           fontSize: 15,
                          //           fontWeight: FontWeight.w400,
                          //         ),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          const SizedBox(height: 10),

                          // Display Containers in a Row with selection check
                          Padding(
                            padding: const EdgeInsets.only(left: 20.0),
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: List.generate(
                                  widget.data[1]['open_state']['body']['items']
                                      .length,
                                      (index) {
                                    var item = widget.data[1]['open_state']
                                    ['body']['items'][index];

                                    return GestureDetector(
                                      onTap: () {
                                        emi = widget.data[1]['open_state']
                                        ['body']['items'][index]['emi'];
                                        print(emi);
                                        setBottomSheetState(() {
                                          selectedIndex =
                                              index; // Update within bottom sheet
                                        });
                                      },
                                      child: Container(
                                        margin: const EdgeInsets.all(10),
                                        padding: const EdgeInsets.all(10),
                                        width: 200,
                                        height: 200,
                                        decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(20.0)),
                                          color: containerColors[
                                          index], // Use pre-generated color
                                        ),
                                        child: Stack(
                                          children: [
                                            Column(
                                              mainAxisAlignment:
                                              MainAxisAlignment.center,
                                              children: [
                                                Text(
                                                  item['emi'] ?? 'No EMI',
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                                Text(
                                                  ' for ' + item['duration'] ??
                                                      'No EMI',
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                                const SizedBox(height: 15),
                                                Text(
                                                  item['subtitle'] ?? 'No EMI',
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                              ],
                                            ),
                                            if (selectedIndex ==
                                                index) // Show check mark if selected
                                              const Positioned(
                                                top: 10,
                                                left: 10,
                                                child: Icon(
                                                  Icons.check_circle,
                                                  color: Colors.white,
                                                  size: 30,
                                                ),
                                              ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Padding(
                            padding: const EdgeInsets.only(left: 30.0),
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ButtonStyle(
                                backgroundColor:
                                MaterialStateProperty.all<Color>(
                                    Colors.transparent),
                                side: MaterialStateProperty.all<BorderSide>(
                                  const BorderSide(
                                    color: Colors.blueGrey, // Border color
                                    width: 2.0, // Border width
                                  ),
                                ),
                              ),
                              child: const Text(
                                'Change account',
                                style: TextStyle(color: Colors.blueGrey),
                              ),
                            ),
                          ),
                          Expanded(
                            child: CustomButton(
                              text: widget.data[1]['cta_text'],
                              onPressed: () {
                                _showBottomSheet2();
                              }),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            );
          },
        );
      },
    ).whenComplete(() {
      setState(() {
        isBottomSheetOpen = false;
      });
      _controller!.reverse(); // Reverse the animation when bottom sheet closes
    });
  }

  final NumberFormat _formatter = NumberFormat('#,##,###');

  double _getMonthlyRate(double amount) {
    return (amount * 0.0104);
  }

  @override
  Widget build(BuildContext context) {
    headText = widget.data[0]['open_state']['body']['title'];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _controller!,
            builder: (context, child) {
              return Positioned(
                top: isBottomSheetOpen ? 80 : 50,
                left: 20,
                right: 20,
                child: Text(
                  isBottomSheetOpen ? creditAmount.toString() : headText,
                  style: TextStyle(
                    fontSize: 20 + _textAnimation!.value * 20,
                    // Adjust the range as needed
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
              );
            },
          ),

          Align(
            alignment: Alignment.center,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20.0, vertical: 40),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
              ),
              width: MediaQuery.of(context).size.width * 0.85,
              height: MediaQuery.of(context).size.height * 0.46,
              // Adjusted height
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SleekCircularSlider(
                    min: 0,
                    max: maxCredit,
                    initialValue: creditAmount,
                    appearance: CircularSliderAppearance(
                      customWidths: CustomSliderWidths(
                        trackWidth: 15,
                        progressBarWidth: 15,
                        handlerSize: 10,
                      ),
                      infoProperties: InfoProperties(
                        modifier: (double value) {
                          return ''; // We will handle custom text inside the slider below
                        },
                      ),
                      startAngle: 270,
                      angleRange: 360,
                      size: 200,
                      customColors: CustomSliderColors(
                        trackColor: Colors.grey[300]!,
                        progressBarColors: [Colors.orange, Colors.deepOrange],
                        hideShadow: true,
                      ),
                    ),
                    onChange: (double value) {
                      setState(() {
                        creditAmount = value;
                      });
                    },
                    innerWidget: (double value) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Credit amount',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 5),
                          // Credit amount with dotted underline
                          Text(
                            '₹ ${_formatter.format(creditAmount)}',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              decoration: TextDecoration.underline,
                              decorationStyle: TextDecorationStyle.dotted,
                            ),
                          ),
                          const SizedBox(height: 5),
                          // Monthly interest rate
                          Text(
                            '@${_getMonthlyRate(creditAmount).toStringAsFixed(2)}% monthly',
                            style: const TextStyle(
                              fontSize: 10,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  Text(
                    widget.data[0]['open_state']['body']['footer'],
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),

          // Bottom Button
          CustomButton(
            text: 'Proceed to EMI Selection',
            onPressed: () {
              // Your button press logic
              _showBottomSheet();
            },
          ),
        ],
      ),
    );
  }
}



